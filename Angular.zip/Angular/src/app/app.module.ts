import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';


import { AppComponent } from './app.component';
import { ImperialMetricCovnListComponent } from './imperial-metric-covn-list/imperial-metric-covn-list.component';
import { ImperialMetricCovnService } from './shared/ImperialMetricConvn/imperial-metric-covn.service';


@NgModule({
  declarations: [
    AppComponent,
    ImperialMetricCovnListComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpModule
  ],
  providers: [ImperialMetricCovnService],
  bootstrap: [AppComponent]
})
export class AppModule { }
