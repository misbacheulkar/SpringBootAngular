/* tslint:disable:no-unused-variable */
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { DebugElement } from '@angular/core';

import { ImperialMetricCovnListComponent } from './imperial-metric-covn-list.component';

describe('ImperialMetricCovnListComponent', () => {
  let component: ImperialMetricCovnListComponent;
  let fixture: ComponentFixture<ImperialMetricCovnListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ImperialMetricCovnListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ImperialMetricCovnListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
