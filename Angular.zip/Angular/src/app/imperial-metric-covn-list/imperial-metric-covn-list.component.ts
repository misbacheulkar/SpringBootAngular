import { Component, OnInit } from '@angular/core';
import { ImperialMetricCovnService } from '../shared/ImperialMetricConvn/imperial-metric-covn.service';

@Component({
  selector: 'app-imperial-metric-covn-list',
  templateUrl: './imperial-metric-covn-list.component.html',
  styleUrls: ['./imperial-metric-covn-list.component.css']
})
export class ImperialMetricCovnListComponent implements OnInit {

imperialMetricCovn: Array<any>;

  constructor(private imperialMetricCovnService: ImperialMetricCovnService) { }

  ngOnInit() {
  this.imperialMetricCovnService.getAll().subscribe(
      data => {
        this.imperialMetricCovn = data;
		},
      error => console.log(error)
    );

  }

}
