/* tslint:disable:no-unused-variable */

import { TestBed, async, inject } from '@angular/core/testing';
import { ImperialMetricCovnService } from './imperial-metric-covn.service';

describe('ImperialMetricCovnService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ImperialMetricCovnService]
    });
  });

  it('should ...', inject([ImperialMetricCovnService], (service: ImperialMetricCovnService) => {
    expect(service).toBeTruthy();
  }));
});
