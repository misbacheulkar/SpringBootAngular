package com.example.imperialmetricconversn.model;

public class Imperialmetricconversn {

    private final long unit;
    private final long ftToinch;
    private final long kmTom;
    private final long mTocm;

    public Imperialmetricconversn(long unit, long ftToinch, long kmTom, long mTocm) {
        this.unit = unit;
        this.ftToinch = ftToinch;
        this.kmTom = kmTom;
        this.mTocm = mTocm;
    }

    public long getUnit() {
        return unit;
    }

    public long getFtToinch() {
		return ftToinch;
	}

	public long getKmTom() {
		return kmTom;
	}

	public long getmTocm() {
		return mTocm;
	}

}