package com.example.imperialmetricconversn.controller;

import com.example.imperialmetricconversn.model.Imperialmetricconversn;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping("/unit/{unit}")
@CrossOrigin(origins = "http://localhost:4200/")
public class ImperialmetricconversnController {


    @RequestMapping(method=RequestMethod.GET)
   
    public @ResponseBody Imperialmetricconversn conversionmetric( @PathVariable("unit") int unit) {
    	return new Imperialmetricconversn(unit, unit*12,unit*1000,unit*100);
    }

}