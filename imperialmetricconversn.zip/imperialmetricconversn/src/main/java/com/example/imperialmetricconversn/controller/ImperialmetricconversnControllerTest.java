package com.example.imperialmetricconversn.controller;

import java.util.Arrays;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.skyscreamer.jsonassert.JSONAssert;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.example.imperialmetricconversn.model.Imperialmetricconversn;


@RunWith(SpringRunner.class)
@WebMvcTest(value = ImperialmetricconversnController.class, secure = false)
public class ImperialmetricconversnControllerTest {

	@Autowired
	private MockMvc mockMvc;

	@MockBean
	private ImperialmetricconversnController ImperialmetricconversnController;

	Imperialmetricconversn mockIm = new Imperialmetricconversn(1,12,1000,100);
			


	@Test
	public void conversionmetricDetail() throws Exception {

		Mockito.when(
				ImperialmetricconversnController.conversionmetric(Mockito.anyInt()
						)).thenReturn(mockIm);;

		RequestBuilder requestBuilder = MockMvcRequestBuilders.get(
				"/unit/1").accept(
				MediaType.APPLICATION_JSON);

		MvcResult result = mockMvc.perform(requestBuilder).andReturn();

		System.out.println(result.getResponse());
		String expected = "{unit:1,ftToinch:12,kmTom:1000,mTocm:100}";

		// {"id":"Course1","name":"Spring","description":"10 Steps, 25 Examples and 10K Students","steps":["Learn Maven","Import Project","First Example","Second Example"]}

		JSONAssert.assertEquals(expected, result.getResponse()
				.getContentAsString(), false);
	}

}
